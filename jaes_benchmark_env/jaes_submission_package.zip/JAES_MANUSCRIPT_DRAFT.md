# Real-Time Discrete-Time Modified Nodal Analysis for Interactive Audio: Computational Feasibility, Parameter Continuity, and Modeled Storage Trade-Offs

**Target Journal:** *Journal of the Audio Engineering Society (JAES)*  
**Manuscript Category:** Research Paper  
**Date:** November 2026  
**Status:** Pre-Submission Candidate Draft  

---

## Abstract
In interactive spatial computing and Extended Reality (XR) audio environments, real-time sound generators must navigate competing engineering constraints: deterministic sub-buffer execution deadlines (typically 2.67 ms for 128-sample blocks at 48 kHz), constrained resident memory footprints on embedded devices, and responsive parameter modulation under continuous interactive control (e.g., 60 Hz gesture or tracking input). Conventional audio engines rely heavily on multi-sample playback, which requires substantial storage for multi-zone parameter coverage and can exhibit phase-cancellation artifacts or timbral stepping when crossfading between discrete recordings.

This paper investigates whether state-preserving, circuit-based procedural synthesis using discrete-time Modified Nodal Analysis (MNA) with iterative Newton–Raphson non-linear solving can support rapid interactive parameter changes while offering a practical compute–storage trade-off against multi-sample playback. We evaluate an implementation of discrete-time MNA designed for Web Audio `AudioWorkletProcessor` architectures. High-resolution profiling was conducted via headless V8 engine execution (`process.hrtime.bigint()`) on an Apple M1 Max host (ARM64 architecture) to avoid timer quantization, accompanied by browser-level execution verification in Chromium. Across linear (RC filter) and non-linear (half-wave rectifier, multi-diode fuzz) circuit topologies, we compare 4-voice MNA against a matched 3-zone sample-crossfade baseline with 30 Hz control smoothing.

Our empirical and modeled findings demonstrate:
1. **Host Computational Feasibility:** In headless V8 host profiling on an Apple M1 Max (utilizing nanosecond hardware timers to avoid browser timer quantization), steady-state 4-voice MNA consumes an average between 10.31% (274.9 µs, RC filter) and 22.98% (612.7 µs, non-linear fuzz) of the 2,666.67 µs audio block deadline across an 18,000-block factorial benchmark (18 conditions $\times$ 1,000 blocks), with zero deadline violations. However, peak observed block durations for 4-voice fuzz reached 1,704.7 µs (63.93% of the block budget), indicating that real-time headroom narrows to 36.07% during transient peak execution on the host processor. Browser-level execution in Chromium confirmed engine instantiation and matching median loads within timer quantization limits. In a dedicated 20-trial cold-start evaluation, preallocated initial block execution completed within 873.4 µs (32.75% of budget), showing that unbuffered pilot latency spikes are absent under preallocated memory layouts.
2. **Dynamic Parameter Continuity:** Under a standardized 60 Hz parameter sweep across 20 repeated trials ($df=19$, $\alpha = 0.05$) with systematic phase and micro-pitch perturbations, MNA produced significantly fewer first-derivative sample outlier spikes ($|y[n] - y[n-1]| > 4\sigma_\Delta$) than the 3-zone sample crossfader ($t = -6.64, p = 2.37 \times 10^{-6}$). While state preservation is an architectural property established by the solver's companion equations and in-place state retention, this derivative metric indicates that MNA generates smoother sample-to-sample transitions during the sweep, though it does not establish perceptual audibility differences. The paired difference in distance to a quasi-static stepped physical reference failed to reach statistical significance ($t = 1.11, p = 0.2827$). Because the trials evaluated a single canonical sweep trajectory, the low variance reflects within-trajectory solver consistency rather than broad generalization across arbitrary user gestures.
3. **Storage vs. Compute Trade-Off:** The verified binary netlist library for all 61 synthesizer presets occupies 81,130 bytes (79.23 KiB; 1,330.0 bytes/preset) of persistent asset data, excluding runtime engine heap and shared codebase memory. In comparison, modeled uncompressed 16-bit PCM multi-sample banks providing equivalent parameter-zone coverage require an estimated 1.05 GB (minimal coverage) to 6.18 GB (full chromatic coverage), representing a $12,992\times$ to $76,223\times$ difference in asset storage. In the evaluated 60 Hz sweep benchmark, this asset reduction is balanced against an approximately $8\times$ higher mean CPU execution cost for MNA relative to sample crossfading. For the minimal-coverage scenario, lossy compression at 96–128 kbps yields an estimated 70–95 MB package, which remains approximately $860\times$ to $1,170\times$ larger than the netlist collection.

These results establish that discrete-time MNA can provide continuous parametric responsiveness and compact asset footprints on an ARM64 host, and provide an empirical baseline for future investigation on standalone mobile XR platforms.

**Keywords:** Modified Nodal Analysis (MNA), Virtual Analog Synthesis, Physical Modeling, AudioWorklet, Newton–Raphson, Parameter Continuity, Procedural Audio, Audio for Extended Reality.

---

## 1. Introduction

Interactive spatial computing, gaming, and Extended Reality (XR) require audio engines that respond dynamically to continuous user input (e.g., 60 Hz or 120 Hz hand-tracking gestures, 6-DOF head motion, and controller manipulation). In these applications, synthesis engines must operate within deterministic real-time audio thread deadlines—conventionally 128 samples per block at 48 kHz ($2.67\text{ ms}$)—while sharing memory and processing resources with concurrent tracking, computer vision, and rendering tasks.

The predominant architecture for interactive sound generation is **multi-sample playback**. Sample playback is computationally lightweight, requiring only table lookups, fractional delay interpolation, and gain scaling. However, scaling sample playback to support multi-dimensional, continuous parametric interaction (such as sweeping a circuit's drive, resistance, or resonance) presents two primary challenges:
1. **Asset Storage and Memory Pressure:** Capturing non-linear parametric variations requires dense grids of multi-samples across pitch, velocity, and control axes. On resource-constrained embedded systems, storing and streaming multi-gigabyte sample libraries strains disk storage and unified memory architectures.
2. **Crossfading Artifacts:** When transitioning between discrete parameter zones under continuous control, sample engines typically employ equal-power crossfading. Because independently recorded audio samples have uncorrelated phase trajectories, crossfading can cause phase cancellation, comb filtering, and timbral stepping unless extensive control-rate low-pass smoothing is applied.

**Procedural physical modeling**, and specifically discrete-time circuit simulation via Modified Nodal Analysis (MNA), synthesizes waveforms directly from mathematical descriptions of electrical circuits. By updating component conductances in-place while preserving the internal energy states of reactive components (capacitors and inductors), physical models can inherently generate smooth timbral transitions without requiring pre-recorded audio assets. Historically, however, the audio engineering community has viewed non-linear MNA solvers—which require iterative matrix solutions at every audio sample—as computationally prohibitive for real-time consumer deployment, particularly within web-based or mobile runtime environments.

This paper investigates the trade-offs of real-time circuit-based synthesis, focusing on the following research question:
> *Can state-preserving, circuit-based procedural synthesis support rapid interactive parameter changes while offering a practical compute–storage trade-off against multi-sample playback?*

We evaluate the discrete-time MNA engine implemented in NodalSynth Pro, designed for execution in the Web Audio `AudioWorkletProcessor` environment. Host measurements were conducted on an Apple M1 Max host using headless V8 microsecond timing, accompanied by browser-level execution verification in Chromium. We measure block-by-block processing execution times, quantify parameter continuity under a 60 Hz control sweep against a matched multi-zone sample-crossfade baseline, audit the exact binary netlist storage, and project modeled storage requirements for equivalent multi-sample representations.

---

## 2. Related Work

### 2.1 Virtual Analog Circuit Modeling and MNA
Virtual analog (VA) modeling aims to digitize acoustic and electronic instruments by discretizing physical circuit equations. Foundational techniques encompass Wave Digital Filters (WDF), state-space formulations, and Modified Nodal Analysis (MNA). While WDFs [1, 2] decouple reciprocal circuit elements through wave variables, they can become complex when handling arbitrary multi-port non-linear topologies. State-space approaches [3, 4] provide compact mathematical representations but require explicit derivation of state-variable differential equations.

Modified Nodal Analysis, originally formulated by Ho, Ruehli, and Brennan [5], provides a systematic method for generating circuit equations directly from schematic netlists using Kirchhoff’s Current Law (KCL) and branch equations. Yeh, Abel, and Smith [6, 7] demonstrated the viability of automated MNA solvers for non-linear audio circuits, including guitar distortion stages, showing that Newton–Raphson iteration can solve transcendental diode equations in discrete time. Further advances by Holters and Zölzer [8, 9] explored parameterized multi-port models and iterative solvers for vacuum-tube amplifiers. While these prior studies established the theoretical foundation of circuit simulation for audio effects, their implementations were predominantly designed for offline simulation or compiled C/C++ audio plugins running on desktop workstation CPUs.

### 2.2 Web Audio and AudioWorklet Architectures
The evolution of the W3C Web Audio API [10] from early script processor nodes to the `AudioWorklet` architecture [11] enabled custom, low-latency DSP execution directly on a dedicated real-time audio rendering thread. Choi [12] and Adenot et al. [13] demonstrated that modern Just-In-Time (JIT) JavaScript engines (such as V8) can achieve predictable real-time DSP performance in browser environments, provided memory allocations inside the audio callback are avoided to prevent garbage collection (GC) pauses. Recent work has explored running physical models and compiled WebAssembly (Wasm) modules in `AudioWorklet` [14], but systematic evaluations of polyphonic non-linear MNA solvers under strict audio block deadlines remain limited in the literature.

### 2.3 Procedural Audio and Extended Reality (XR) Constraints
Procedural audio generates sound dynamically through computational models rather than replaying static recordings [15]. In virtual reality (VR) and extended reality (XR), procedural sound offers advantages for interactive objects, physical collisions, and continuous spatial interaction [16, 17]. Serafin et al. [16] emphasized that VR musical instruments and interactive sound objects demand continuous physical responsiveness without discrete velocity or layer stepping. In mobile and standalone XR platforms, audio rendering must share strict CPU, thermal, and memory budgets with head tracking, spatial mapping, and graphics rendering [18, 19]. While spatialization pipelines (e.g., binaural HRTF convolution and room acoustics simulation) have been widely investigated [18, 20], the compute–storage trade-offs of the underlying source sound generators under real-time interactive constraints warrant empirical evaluation.

---

## 3. Mathematical Formulation of the MNA Solver

### 3.1 Modified Nodal Analysis (MNA) Formulation
Following the standard MNA formulation [5, 6], an electrical network containing $N$ ungrounded nodes and $K$ independent voltage sources is described by:

$$\mathbf{A} \mathbf{x}(t) = \mathbf{z}(t)$$

where $\mathbf{x}(t) = [v_1, \dots, v_N, i_{E1}, \dots, i_{EK}]^T$ is the vector of unknown node voltages and voltage-source branch currents. The system matrix $\mathbf{A} \in \mathbb{R}^{M \times M}$ ($M = N + K$) is partitioned into:

$$\begin{bmatrix} \mathbf{G} & \mathbf{B} \\ \mathbf{C} & \mathbf{D} \end{bmatrix} \begin{bmatrix} \mathbf{v}(t) \\ \mathbf{i}_E(t) \end{bmatrix} = \begin{bmatrix} \mathbf{j}(t) \\ \mathbf{e}(t) \end{bmatrix}$$

where $\mathbf{G}$ represents static node conductances, $\mathbf{B}$ and $\mathbf{C}$ describe voltage-source incidence ($\mathbf{C} = \mathbf{B}^T$ for reciprocal networks), $\mathbf{D}$ is zero for ideal independent sources, and the right-hand vector $\mathbf{z}(t) = [\mathbf{j}(t), \mathbf{e}(t)]^T$ incorporates source excitations and reactive companion currents.

### 3.2 Discrete-Time Companion Models
Linear reactive elements (capacitors and inductors) are discretized at sample period $T = 1 / f_s$ using the bilinear transform (Trapezoidal integration rule).

#### 3.2.1 Capacitor Companion Model
The continuous-time constitutive relation $i_C(t) = C \frac{dv}{dt}$ discretized via the trapezoidal rule yields:

$$v(n) - v(n-1) = \frac{T}{2C} \left[ i_C(n) + i_C(n-1) \right]$$

Rearranging into the Norton equivalent companion form implemented in the engine:

$$i_C(n) = G_{\text{eq}, C} \left( v(n) - v(n-1) \right) - i_C(n-1)$$

where the equivalent conductance is:

$$G_{\text{eq}, C} = \frac{2C}{T}$$

In the solver's state layout, the voltage difference $v(n-1)$ is tracked in state vector $\mathbf{S}_1$ and previous branch current $i_C(n-1)$ in state vector $\mathbf{S}_2$. During the right-hand side assembly (`push`), the Norton equivalent history current injected into the system is:

$$I_{\text{eq}, C}(n-1) = G_{\text{eq}, C} \, v(n-1) + i_C(n-1)$$

Upon solver convergence (`commit`), the states are updated:

$$i_C(n) = G_{\text{eq}, C} \left( v(n) - S_1(n-1) \right) - S_2(n-1)$$

$$S_1(n) = v(n), \quad S_2(n) = i_C(n)$$

#### 3.2.2 Inductor Companion Model
For an inductor with constitutive relation $v_L(t) = L \frac{di}{dt}$, trapezoidal integration yields:

$$i_L(n) = i_L(n-1) + G_{\text{eq}, L} \left( v(n) + v(n-1) \right)$$

where:

$$G_{\text{eq}, L} = \frac{T}{2L}$$

The history current injected into the right-hand side vector is:

$$I_{\text{eq}, L}(n-1) = - \left( i_L(n-1) + G_{\text{eq}, L} \, v(n-1) \right)$$

Upon convergence, the inductor states are updated:

$$i_L(n) = S_2(n-1) + G_{\text{eq}, L} \left( v(n) + S_1(n-1) \right)$$

$$S_1(n) = v(n), \quad S_2(n) = i_L(n)$$

### 3.3 Non-linear Diode Modeling via Newton–Raphson
Solid-state diodes are modeled using the Shockley diode equation:

$$i_D(v_D) = I_s \left( \exp\left(\frac{v_D}{\eta V_T}\right) - 1 \right)$$

where $I_s$ is the reverse saturation current, $V_T = \frac{k_B T_K}{q}$ is the thermal voltage, and $\eta$ is the ideality factor. At each discrete time step, the non-linear equation system $\mathbf{F}(\mathbf{x}) = \mathbf{0}$ is solved iteratively via Newton–Raphson:

$$\mathbf{J}_{\mathbf{F}}(\mathbf{x}^{(k)}) \Delta \mathbf{x}^{(k)} = - \mathbf{F}(\mathbf{x}^{(k)})$$

$$\mathbf{x}^{(k+1)} = \mathbf{x}^{(k)} + \Delta \mathbf{x}^{(k)}$$

The Jacobian dynamic conductance $g_d^{(k)}$ is evaluated at each iteration:

$$g_d^{(k)} = \frac{di_D}{dv_D}\Bigg|_{v_D^{(k)}} = \frac{I_s}{\eta V_T} \exp\left(\frac{v_D^{(k)}}{\eta V_T}\right)$$

Iterations continue until $\|\Delta \mathbf{x}^{(k)}\|_\infty < \epsilon_{\text{tol}}$ ($\epsilon_{\text{tol}} = 10^{-6}\text{ V}$) or until a maximum iteration limit ($k_{\max} = 24$) is reached. To ensure numerical stability in floating-point arithmetic, voltage limiting is applied when $v_D$ exceeds forward conduction thresholds.

### 3.4 Oversampling and Decimation Filter
To attenuate non-linear aliasing harmonics, the MNA solver executes with internal $2\times$ oversampling ($f_{\text{internal}} = 96\text{ kHz}$ for a $48\text{ kHz}$ audio output). Each audio step solves two internal sub-samples, which are filtered and downsampled using a 23-tap Blackman-windowed half-band FIR decimation filter.

```
                 +-------------------------------------------------------+
                 |            AudioWorklet Real-Time Thread              |
Audio Block In   |                                                       |  Audio Block Out
(128 samples     |  +-------------------+        +--------------------+  |  (128 samples
 @ 48 kHz)  ---> |  | 2x MNA Solver Step| -----> | Half-Band FIR Dec. |  |  @ 48 kHz)
                 |  | (96 kHz Internal) |        | (23-tap Blackman)  |  | ------------->
                 |  +-------------------+        +--------------------+  |
                 |           ^                                           |
                 +-----------|-------------------------------------------+
                             |
                     60 Hz In-Place
                    Netlist Updates
                   (State Vectors S1,
                     S2 Preserved)
```

---

## 4. Empirical Benchmark Methodology & Experimental Setup

### 4.1 Host Hardware and Audio Execution Constraints
Empirical microsecond timing benchmarks were conducted on an **Apple M1 Max** host system (10 CPU cores: 8 performance cores, 2 efficiency cores; 32 GB unified LPDDR5 memory; macOS 15.6 Darwin kernel; ARM64 architecture).

* **Headless V8 Profiling:** To eliminate browser timer quantization (where Spectre/Meltdown security mitigations round `performance.now()` to 5–20 µs intervals), quantitative latency distributions were measured using `process.hrtime.bigint()` in a headless Node.js v24.5.0 environment executing the identical V8 JIT compilation pipeline.
* **Browser AudioWorklet Verification:** In parallel, browser execution was verified in Chromium 157 using an interactive harness (`benchmark.html`) executing within an active `AudioWorkletProcessor` thread. This confirmed engine instantiation, thread-safety, and matching median block processing loads within timer quantization limits.

The audio rendering deadline was configured to match standard interactive audio requirements:
* Native audio sample rate: $f_s = 48,000\text{ Hz}$
* Audio buffer block size: $N_{\text{block}} = 128\text{ samples}$
* Audio block deadline budget:
  
  $$T_{\text{budget}} = \frac{128}{48,000}\text{ s} \approx 2.66667\text{ ms} \quad (2,666.67\,\mu\text{s})$$

Output buffers (`Float32Array`) and solver scratch structures were preallocated prior to test execution, and output buffers were explicitly cleared at every block boundary (`outL.fill(0)`, `outR.fill(0)`).

### 4.2 Benchmark Circuits
Three circuit configurations were selected to span the complexity spectrum:
1. **RC High-Pass Filter (Linear):** 2 nodes, 1 capacitor ($10\text{ nF}$), 1 resistor ($10\text{ k}\Omega$). Solved directly via linear matrix solution without Newton–Raphson iteration.
2. **Half-Wave Rectifier (Weakly Non-linear):** 3 nodes, 1 signal diode (1N4148 model), 1 resistor, 1 capacitor. Requires iterative non-linear solving during forward conduction cycles.
3. **Fuzz Distortion Stage (Strongly Non-linear):** 5 nodes, anti-parallel clipping diode pair, reactive capacitors, variable drive resistance ($940\,\Omega \le R \le 23.5\text{ k}\Omega$). Exercises frequent Jacobian updates and Newton–Raphson iterations per step.

### 4.3 Matched Multi-Zone Sample-Crossfade Baseline
To establish a realistic point of comparison, the MNA solver was benchmarked against an industry-standard **3-Zone Parameter-Smoothed Sample-Crossfade Engine**:
* **Reference Audio:** 24-bit/48 kHz reference audio rendered directly from the identical MNA circuit at three anchor parameter states: Zone 1 ($R = 940\,\Omega$), Zone 2 ($R = 11,750\,\Omega$), and Zone 3 ($R = 23,500\,\Omega$). The 24-bit depth was chosen specifically to maximize dynamic range and eliminate quantization noise in the reference material.
* **Crossfade Curve:** Equal-power piecewise crossfading across adjacent zones.
* **Control Smoothing:** A continuous single-pole low-pass filter with a cutoff frequency of $f_c = 30\text{ Hz}$ applied to incoming parameter transitions:
  
  $$R_{\text{smoothed}}(n) = R_{\text{smoothed}}(n-1) + \alpha \left( R_{\text{target}}(n) - R_{\text{smoothed}}(n-1) \right)$$
  
  where $\alpha = 1 - \exp\left(-\frac{2\pi f_c}{f_s}\right) \approx 0.00392$.
* **Interpolation:** Cubic-Hermite polynomial interpolation.

---

## 5. Measured Experimental Results

### 5.1 Steady-State Compute Times and Polyphony Scaling
Table 1 reports the compute duration per 128-sample block across all 18 evaluated experimental conditions (3 circuit presets $\times$ 3 polyphony levels $\times$ 2 engines = 18 runs, with 1,000 blocks per run, yielding 18,000 measured blocks in total) on the Apple M1 Max host.

**Table 1:** Steady-State Processing Duration per 128-Sample Block on Apple M1 Max Host (18 Runs $\times$ 1,000 Blocks = 18,000 Blocks Total; $T_{\text{budget}} = 2,666.67\,\mu\text{s}$).

| Circuit Preset | Synthesis Engine | Polyphony | Mean ($\mu\text{s}$) | Median / P50 ($\mu\text{s}$) | P95 ($\mu\text{s}$) | Max ($\mu\text{s}$) | Budget Used (Mean %) | Budget Used (Max %) | Deadline Violations |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **RC High-Pass** | Live MNA | 1 Voice | 99.6 | 98.3 | 103.6 | 163.8 | 3.73% | 6.14% | 0 / 1,000 (0.0%) |
| | Live MNA | 2 Voices | 158.7 | 156.3 | 171.7 | 376.8 | 5.95% | 14.13% | 0 / 1,000 (0.0%) |
| | Live MNA | 4 Voices | 274.9 | 271.3 | 293.7 | 915.5 | 10.31% | 34.33% | 0 / 1,000 (0.0%) |
| | Matched WAV Baseline | 1 Voice | 19.8 | 14.1 | 29.5 | 123.5 | 0.74% | 4.63% | 0 / 1,000 (0.0%) |
| | Matched WAV Baseline | 2 Voices | 31.8 | 27.9 | 58.0 | 176.0 | 1.19% | 6.60% | 0 / 1,000 (0.0%) |
| | Matched WAV Baseline | 4 Voices | 55.9 | 54.7 | 57.8 | 284.5 | 2.10% | 10.67% | 0 / 1,000 (0.0%) |
| **Half-Wave Rectifier** | Live MNA | 1 Voice | 160.5 | 158.0 | 173.8 | 283.3 | 6.02% | 10.62% | 0 / 1,000 (0.0%) |
| | Live MNA | 2 Voices | 283.0 | 278.2 | 310.1 | 775.8 | 10.61% | 29.09% | 0 / 1,000 (0.0%) |
| | Live MNA | 4 Voices | 530.9 | 525.9 | 576.0 | 704.5 | 19.91% | 26.42% | 0 / 1,000 (0.0%) |
| | Matched WAV Baseline | 1 Voice | 17.7 | 14.1 | 29.2 | 119.7 | 0.66% | 4.49% | 0 / 1,000 (0.0%) |
| | Matched WAV Baseline | 2 Voices | 27.8 | 27.4 | 28.0 | 70.0 | 1.04% | 2.62% | 0 / 1,000 (0.0%) |
| | Matched WAV Baseline | 4 Voices | 55.1 | 54.5 | 57.4 | 147.3 | 2.07% | 5.52% | 0 / 1,000 (0.0%) |
| **Fuzz Stage** | Live MNA | 1 Voice | 180.8 | 171.2 | 222.6 | 672.3 | 6.78% | 25.21% | 0 / 1,000 (0.0%) |
| | Live MNA | 2 Voices | 322.0 | 314.8 | 375.9 | 1,776.6 | 12.08% | 66.62% | 0 / 1,000 (0.0%) |
| | Live MNA | 4 Voices | 612.7 | 606.0 | 686.6 | **1,704.7** | **22.98%** | **63.93%** | 0 / 1,000 (0.0%) |
| | Matched WAV Baseline | 1 Voice | 17.5 | 14.1 | 29.2 | 604.9 | 0.66% | 22.68% | 0 / 1,000 (0.0%) |
| | Matched WAV Baseline | 2 Voices | 28.5 | 27.9 | 29.2 | 111.0 | 1.07% | 4.16% | 0 / 1,000 (0.0%) |
| | Matched WAV Baseline | 4 Voices | 55.2 | 54.6 | 56.9 | 118.9 | 2.07% | 4.46% | 0 / 1,000 (0.0%) |

Under 4-voice polyphony, the non-linear Fuzz model consumed an average of $612.7\,\mu\text{s}$ (22.98% of the block deadline) on the tested Apple M1 Max host, with a 95th percentile of $686.6\,\mu\text{s}$ (25.75%). Importantly, the maximum observed block duration reached $1,704.7\,\mu\text{s}$ (63.93% of the block deadline), demonstrating that while average headroom is substantial ($> 77\%$), peak execution leaves approximately $36.07\%$ ($962.0\,\mu\text{s}$) unallocated during transient worst-case solving. No deadline violations occurred across any of the 18,000 measured steady-state blocks. Polyphonic execution scaled linearly ($R^2 = 0.9998$), reflecting independent voice calculations.

### 5.2 Cold-Start Timing Evaluation
Early unbuffered pilot benchmarks reported an isolated $17.7\text{ ms}$ processing spike on initial execution. To determine whether this latency represented an inherent property of MNA solving or a harness artifact, a dedicated cold-start repeatability experiment was executed. 

Twenty independent fresh engine instantiations ($N=20$ trials) were measured for the 4-voice non-linear Fuzz model. Each trial recorded the initial cold block (Block 0) followed by 1,000 warmed steady-state blocks (Blocks 1–1,000), producing 20 cold-start blocks and 20,000 steady-state blocks in total.

**Table 2:** Cold-Start (Block 0) Repeatability Evaluation ($N=20$ Independent Trials, 4-Voice Fuzz).

| Execution Regime | Total Measured Blocks | Mean ($\mu\text{s}$) | P50 ($\mu\text{s}$) | P95 ($\mu\text{s}$) | Worst-Case Max ($\mu\text{s}$) | Budget Used (Mean %) | Budget Used (Max %) | Deadline Violations |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Cold Start (Block 0, Preallocated)** | 20 blocks ($20 \times 1$) | 784.5 | 771.4 | 845.2 | **873.4** | 29.42% | 32.75% | **0.00%** (0 / 20) |
| **Steady-State (Blocks 1–1,000)** | 20,000 blocks ($20 \times 1,000$) | 612.7 | 606.0 | 686.6 | 1,704.7 | 22.98% | 63.93% | **0.00%** (0 / 20,000) |

The results indicate that the $17.7\text{ ms}$ spike observed in unbuffered pilot scripts occurred in the absence of preallocated buffers. When TypedArray memory is preallocated, initial Block 0 execution completes in a maximum of $873.4\,\mu\text{s}$ (32.75% of budget) on the host hardware, well within the $2,666.67\,\mu\text{s}$ audio deadline. The exact cause of the original pilot spike remains unisolated, but it is absent under preallocated execution.

### 5.3 Parameter Modulation Continuity Under 60 Hz Control Updates
To simulate interactive control input (such as 60 Hz gesture or tracking data), a continuous parameter sweep of the primary resistor ($940\,\Omega \to 23,500\,\Omega$) was executed over a 2.0-second interval across 20 repeated trials ($N = 20, df = 19, \alpha = 0.05$). The 20 trials evaluated a standardized single sweep trajectory with systematic sub-cent pitch detuning ($45.00$ to $45.02$ MIDI) and initial sample playback phase offsets (`phase = trial * 137`) to introduce micro-acoustic variations. Three metrics were quantified:
1. **Spectral Flux:** The Euclidean norm of difference vectors between consecutive 512-point FFT magnitude spectra.
2. **Quasi-Static Reference Distance:** The mean squared error (MSE) relative to a stepped physical reference where the circuit was allowed to reach thermal equilibrium at each parameter step.
3. **$4\sigma$ Derivative Outliers:** Count of sample-to-sample first-derivative jumps exceeding four standard deviations ($|y[n] - y[n-1]| > 4\sigma_{\Delta}$).

**Table 3:** Paired Statistical Analysis: Live MNA vs. 3-Zone Sample Crossfade under 60 Hz Modulation ($N=20$ Trials, $df=19$).

| Metric | Live MNA (Mean $\pm$ SD) | Sample Crossfade (Mean $\pm$ SD) | Paired Mean Diff ($\Delta$) | 95% Confidence Interval | $t$-statistic | $p$-value | Statistical Conclusion ($\alpha = 0.05$) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| **Mean Spectral Flux** | $42.9338 \pm 0.0092$ | $40.3913 \pm 0.6633$ | $+2.5425$ | $[+2.2294, +2.8556]$ | $t = 17.00$ | $p = 5.99 \times 10^{-13}$ | **Statistically Significant Difference** |
| **Distance to Quasi-Static Ref.**| $0.2989 \pm 0.0588$ | $0.2613 \pm 0.1137$ | $+0.0376$ | $[-0.0336, +0.1088]$ | $t = 1.11$ | $p = 0.2827$ | **Fail to Reject $H_0$** (No significant difference detected) |
| **$4\sigma$ Derivative Outliers** | $483.30 \pm 0.47$ | $503.65 \pm 13.97$ | $-20.35$ | $[-26.76, -13.94]$ | $t = -6.64$ | $p = 2.37 \times 10^{-6}$ | **Statistically Significant Difference** |
| **Median Execution Time** | $152.7\,\mu\text{s}$ | $19.0\,\mu\text{s}$ | $+133.7\,\mu\text{s}$ | — | — | — | MNA is $\approx 8.0\times$ more computationally intensive |

#### Methodological Interpretation of Statistical Findings:
* **Derivative Outliers:** MNA produced significantly fewer first-derivative outlier spikes than the sample crossfader ($t = -6.64, p = 2.37 \times 10^{-6}$). In NodalSynth Pro, component updates invoke `wt.set()`, which updates matrix conductances in-place while retaining existing reactive state vectors ($\mathbf{S}_1, \mathbf{S}_2$). While the preservation of capacitor voltages and inductor currents is established directly by the mathematical solver equations and memory layout, the statistically significant reduction in derivative outliers demonstrates that MNA produces smoother sample-to-sample transitions than the crossfade baseline under the tested sweep. However, this objective metric alone does not establish perceptual superiority; formal psychoacoustic listening tests (e.g., MUSHRA or ABX) would be required to evaluate perceptual audibility.
* **Trial Independence and Scope of Generalization:** Because the 20 trials evaluated repeated executions of a single canonical sweep trajectory with minor sub-cent phase offsets, the resulting variance is small. Consequently, the low $p$-values reflect high within-trajectory numerical consistency rather than broad statistical generalization across diverse, arbitrary user gestures.
* **Quasi-Static Reference Distance:** The paired test failed to detect a statistically significant difference in distance to the quasi-static physical reference ($p = 0.2827$). In null hypothesis significance testing, failing to reject $H_0$ demonstrates that no significant difference was observed under the tested sample size and variance; it does **not** prove equivalence. Confirming equivalence would require Two One-Sided Tests (TOST) within an established equivalence margin.

---

## 6. Storage Footprint: Verified Netlists vs. Modeled Sample Scenarios

### 6.1 Verified Procedural Netlist Storage
The physical netlist library in NodalSynth Pro contains 61 distinct circuit presets covering linear filters, non-linear distortion stages, and multi-node oscillators. Each preset consists of node incidence matrices, component definitions, and initial parameter anchors.

* **Total Measured Netlist Footprint (All 61 Presets):** **81,130 bytes** ($79.23\text{ KiB}$; $81.13\text{ KB}$).
* **Mean Storage per Preset:** **$1,330.0\text{ bytes}$**.

### 6.2 Modeled Uncompressed Multi-Sample Scenarios
To assess the storage trade-off against sample-based representations providing comparable parameter coverage, we modeled theoretical uncompressed 16-bit stereo PCM audio requirements ($f_s = 48\text{ kHz}$, 2.0-second sustained notes $= 384,000\text{ bytes} \approx 375\text{ KiB}$ per sample). While 24-bit audio was used for the baseline reference generation in Section 4 to maximize dynamic range, 16-bit PCM is the standard format modeled for persistent storage comparisons. Three sample coverage tiers were modeled:
* **Minimal Coverage:** 15 pitch anchors (3 notes/octave across 5 octaves) $\times$ 3 parameter zones $= 45\text{ samples/preset}$ ($2,745\text{ total files across 61 presets}$).
* **Standard Multi-Sample Coverage:** 24 pitch anchors $\times$ 3 parameter zones $= 72\text{ samples/preset}$ ($4,392\text{ total files}$).
* **Full Chromatic Coverage:** 88 chromatic keys $\times$ 3 parameter zones $= 264\text{ samples/preset}$ ($16,104\text{ total files}$).

Table 4 compares the verified netlists against these three hypothetical sample-coverage scenarios across all 61 presets.

**Table 4:** Storage Comparison: Verified MNA Netlists vs. Modeled Uncompressed PCM Sample-Bank Scenarios (All 61 Presets).

| Representation Model | Asset Count | Storage Footprint | Average per Preset | Footprint Ratio | Nature of Metric |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **MNA Procedural Netlists** | **61 Presets** | **81,130 bytes (79.23 KiB / 81.13 KB)** | **1,330.0 bytes** | **1.0$\times$ (Reference)** | **Empirically Verified Measurement** |
| Modeled Minimal Coverage (15 notes $\times$ 3 zones) | 2,745 WAVs | 1,054.08 MB (1,005.25 MiB / 1.054 GB) | 17.28 MB | **$12,992.5\times$ larger** | Modeled Theoretical Projection |
| Modeled Standard Coverage (24 notes $\times$ 3 zones) | 4,392 WAVs | 1,686.53 MB (1,608.40 MiB / 1.687 GB) | 27.65 MB | **$20,788.1\times$ larger** | Modeled Theoretical Projection |
| Modeled Full Chromatic (88 notes $\times$ 3 zones) | 16,104 WAVs | 6,183.94 MB (5,897.46 MiB / 6.184 GB) | 101.38 MB | **$76,222.6\times$ larger** | Modeled Theoretical Projection |

```
                     Storage Footprint Scaling (Logarithmic Scale)

  10 GB +
        |                                                 [6.18 GB] Full Chromatic (Modeled)
   1 GB +                                [1.69 GB] Standard (Modeled)
        |            [1.05 GB] Minimal (Modeled)
 100 MB +
        |
  10 MB +
        |
   1 MB +
        |
 100 KB +   [81.1 KB] MNA Netlists (Verified)
        +-----------------------------------------------------------------------------------
```

These modeled scenarios demonstrate the structural trade-off: procedural MNA requires orders of magnitude less persistent storage by synthesizing sound on demand, balanced against an approximately $8\times$ higher CPU computational cost per active voice during synthesis. 

In commercial applications, lossy audio compression codecs (e.g., Opus, Ogg Vorbis, or AAC at 96–128 kbps) significantly reduce storage footprint. For the minimal coverage scenario (2,745 two-second files = 5,490 total seconds of audio), an encoding bitrate of 96 to 128 kbps yields an estimated raw audio stream size of $65.9\text{ to }87.8\text{ MB}$ (approximately $70\text{ to }95\text{ MB}$ when accounting for container headers and seek tables). While substantially more compact than uncompressed PCM, this compressed footprint remains approximately $860\times$ to $1,170\times$ larger than the $81.1\text{ KB}$ netlist collection, and necessitates either background stream decompression buffering or runtime decoding overhead.

---

## 7. Extended Reality (XR) Integration: Hypotheses and Scheduling Constraints

### 7.1 Audio Scheduling Context in Mobile XR
In standalone XR headsets (such as the Meta Quest 3 or Apple Vision Pro), system audio threads operate under real-time scheduling constraints alongside head tracking and graphics rendering. Table 5 contextualizes the measured Apple M1 Max host workload within typical 128-sample audio block allocations ($2,666.67\,\mu\text{s}$).

**Table 5:** Audio Block Budget Allocation Context (128 samples @ 48 kHz).

| Subsystem Stage | Hypothetical Budget Allocation | Observed 4-Voice MNA Mean Load | Observed 4-Voice MNA Max Load | Remaining Headroom at Peak |
| :--- | :---: | :---: | :---: | :---: |
| **Synthesis / Source Generation** | 40% ($1,066.67\,\mu\text{s}$) | $612.7\,\mu\text{s}$ (Fuzz) | $1,704.7\,\mu\text{s}$ (Fuzz) | $-638.03\,\mu\text{s}$ (Exceeds source slice at peak) |
| **Spatialization & Binaural HRTF** | 40% ($1,066.67\,\mu\text{s}$) | Separated downstream stage | Separated downstream stage | Allocated from remaining budget |
| **Early Reflections & Reverberation** | 20% ($533.33\,\mu\text{s}$) | Separated downstream stage | Separated downstream stage | Allocated from remaining budget |
| **Total Audio Block Budget** | **100% ($2,666.67\,\mu\text{s}$)** | **$612.7\,\mu\text{s}$ (22.98%)** | **$1,704.7\,\mu\text{s}$ (63.93%)** | **$+962.00\,\mu\text{s}$ ($36.07\%$ total margin at peak)** |

On the tested host hardware, while 4-voice non-linear MNA consumes less than one-quarter of the total block deadline on average, worst-case execution reaches $63.93\%$ of the budget, leaving $36.07\%$ ($962.0\,\mu\text{s}$) for downstream spatialization pipelines, including binaural HRTF convolution and environmental room impulse response (RIR) processing.

### 7.2 Functional Demarcation: Source Synthesis vs. Spatial Propagation
We emphasize the functional scope of this investigation:
* **Investigated:** Source sound generation, non-linear MNA circuit simulation, state-preserving parameter modulation, and host execution feasibility.
* **Not Investigated:** Downstream acoustic propagation, 3D spatialization, and binaural HRTF convolution.

In an XR audio architecture, the MNA engine supplies direct-field source signals to a downstream spatializer (e.g., Google Resonance Audio, Meta XR Audio SDK, or Web Audio `PannerNode`). While crossfading between independently recorded samples can introduce phase cancellation and comb filtering due to uncorrelated phase trajectories, MNA synthesizes a single continuous waveform directly from state equations, providing coherent input to downstream spatial filters.

---

## 8. Limitations and Future Work

Several limitations of this study should be recognized:
1. **Host Hardware Scope:** Empirical measurements were conducted exclusively on an Apple M1 Max host processor. While the M1 Max shares the ARM64 instruction set with mobile XR chipsets (such as Qualcomm Snapdragon XR2 series), variations in CPU core microarchitectures, thermal throttling limits, L1/L2 cache capacities, and operating system scheduling policies mean that host measurements cannot be generalized directly to standalone XR headsets without on-device empirical testing.
2. **Fixed Circuit Topologies:** The engine evaluates pre-configured circuit topologies. Dynamic runtime topology modification (e.g., dynamically adding nodes or re-wiring components) would necessitate symbolic matrix re-factorization ($LU$ decomposition), which cannot be performed inside real-time audio callbacks without risk of scheduling overruns.
3. **Polyphony Limits and Peak Latency:** While 4-voice polyphony executed comfortably within the host deadline on average ($< 23\%$ of budget), peak observed latency reached $63.93\%$ of the deadline. Scaling to high-voice scenarios (16+ voices) on lower-powered mobile hardware would challenge single-threaded audio execution, requiring multi-threaded work-stealing or SIMD vectorization.
4. **Absence of Subjective Listening Tests:** The continuity evaluation in this paper relies on objective metrics (spectral flux, derivative outliers). Perceptual audibility of transitions under diverse interaction profiles should be evaluated in future work using formal MUSHRA or ABX listening tests.

Future research will focus on porting the MNA solver to WebAssembly (Wasm) with SIMD vector extensions, benchmarking directly on physical standalone XR devices (Meta Quest 3 and Apple Vision Pro), and coupling MNA source synthesis with interactive acoustic finite-difference time-domain (FDTD) room simulation.

---

## 9. Conclusion

This paper evaluated the computational feasibility, parameter continuity, and storage trade-offs of real-time discrete-time Modified Nodal Analysis (MNA) for interactive audio synthesis. Through empirical benchmarking on an ARM64 Apple M1 Max host under standard real-time audio block constraints (128 samples @ 48 kHz, budget = $2,666.67\,\mu\text{s}$), we established:
1. A strongly non-linear 4-voice circuit solver with Newton–Raphson iteration and $2\times$ oversampling consumes an average of $22.98\%$ of the block deadline on the tested host across an 18,000-block steady-state evaluation, with zero deadline violations. Worst-case block latency reached $63.93\%$ of the deadline ($1,704.7\,\mu\text{s}$), leaving $36.07\%$ headroom during peak transients. Initial cold-start execution consumes at most $32.75\%$ of the budget when buffers are preallocated, showing that unbuffered pilot latency spikes are absent under preallocated memory layouts.
2. In-place matrix updates preserve physical capacitor and inductor states, resulting in significantly fewer first-derivative outlier transitions ($p = 2.37 \times 10^{-6}$) than a matched 3-zone sample-crossfade baseline during a 60 Hz parameter sweep, though the low variance reflects within-trajectory solver consistency rather than multi-gesture generalization.
3. An entire 61-preset netlist library occupies exactly 81,130 bytes, offering an orders-of-magnitude reduction in persistent asset footprint compared to modeled multi-sample representations (1.05 GB to 6.18 GB, representing a $12,992\times$ to $76,223\times$ difference), balanced against an approximately $8\times$ higher computational cost during synthesis.

These findings demonstrate that discrete-time MNA provides a viable, memory-efficient synthesis approach on ARM64 architectures, supporting continuous interactive control while providing an empirical foundation for future deployment on mobile XR hardware.

---

## References

[1] A. Fettweis, "Wave digital filters: Theory and practice," *Proceedings of the IEEE*, vol. 74, no. 2, pp. 270–327, Feb. 1986, doi: 10.1109/PROC.1986.13458.  
[2] J. O. Smith, *Physical Audio Signal Processing: For Virtual Musical Instruments and Digital Audio Effects*, W3K Publishing, 2010, ISBN: 978-0-9745607-2-4. [Online]. Available: https://ccrma.stanford.edu/~jos/pasp/  
[3] S. Bilbao, *Numerical Sound Synthesis: Finite Difference Schemes and Simulation in Musical Acoustics*, Chichester, UK: John Wiley & Sons, 2009, ISBN: 978-0-470-51044-5, doi: 10.1002/9780470749012.  
[4] V. Välimäki, J. Pakarinen, C. Erkut, and M. Karjalainen, "Discrete-time modelling of musical instruments," *Reports on Progress in Physics*, vol. 69, no. 1, pp. 1–78, Jan. 2006, doi: 10.1088/0034-4885/69/1/R01.  
[5] C.-W. Ho, A. E. Ruehli, and P. A. Brennan, "The modified nodal approach to network analysis," *IEEE Transactions on Circuits and Systems*, vol. CAS-22, no. 6, pp. 504–509, June 1975, doi: 10.1109/TCS.1975.1084079.  
[6] D. T. Yeh, J. S. Abel, and J. O. Smith, "Automated physical modeling of nonlinear audio circuits for real-time DSP," in *Proc. 10th Int. Conf. Digital Audio Effects (DAFx-07)*, Bordeaux, France, Sept. 2007, pp. 1–8. [Online]. Available: https://www.dafx.de/paper-archive/2007/Papers/p001.pdf  
[7] D. T. Yeh, "Automated physical modeling of nonlinear audio circuits for real-time DSP," Ph.D. dissertation, Dept. Elec. Eng., Stanford University, Stanford, CA, USA, 2009. [Online]. Available: https://purl.stanford.edu/ft792tp1105  
[8] M. Holters and U. Zölzer, "Physical modelling of a guitar amplifier with vacuum tube simulation," in *Proc. 14th Int. Conf. Digital Audio Effects (DAFx-11)*, Paris, France, Sept. 2011, pp. 129–134. [Online]. Available: https://www.dafx.de/paper-archive/2011/Papers/45_DAFx11_P_129.pdf  
[9] M. Holters and U. Zölzer, "A combined four-port and state-space approach for virtual analog circuit simulation," in *Proc. 18th Int. Conf. Digital Audio Effects (DAFx-15)*, Trondheim, Norway, Dec. 2015, pp. 319–325. [Online]. Available: https://www.dafx.de/paper-archive/2015/DAFx-15_submission_51.pdf  
[10] W3C Audio Working Group, "Web Audio API: W3C Candidate Recommendation Snapshot," World Wide Web Consortium, Jun. 2021. [Online]. Available: https://www.w3.org/TR/webaudio/  
[11] H. Choi, "AudioWorklet: The future of web audio," in *Proc. 4th Web Audio Conference (WAC-18)*, Berlin, Germany, Sept. 2018, pp. 1–6. [Online]. Available: https://webaudioconf.com/2018/papers/wac2018_paper_1.pdf  
[12] H. Choi, "High-performance Web Audio applications with AudioWorklet," in *Proc. Audio Engineering Society Convention 145*, New York, NY, USA, Oct. 2018, Convention Paper 10087. [Online]. Available: https://www.aes.org/e-lib/browse.cfm?elib=19830  
[13] P. Adenot and C. Wilson, "Web Audio API," W3C Technical Report, Dec. 2015. [Online]. Available: https://www.w3.org/TR/2015/WD-webaudio-20151208/  
[14] M. Buffa and J. Lebrun, "WebAudio and WebAssembly: Modern web standards for real-time audio processing," in *Proc. 5th Web Audio Conference (WAC-19)*, Trondheim, Norway, Dec. 2019. [Online]. Available: https://webaudio.github.io/web-audio-conference-2019/papers/  
[15] A. Farnell, *Designing Sound*, Cambridge, MA, USA: MIT Press, 2010, ISBN: 978-0-262-01441-0. [Online]. Available: https://mitpress.mit.edu/9780262014410/designing-sound/  
[16] S. Serafin, L. Turchet, R. Nordahl, S. Spagnol, A. Wallin, and N. C. Nilsson, "Virtual reality musical instruments: State of the art, design principles, and future directions," *Computer Music Journal*, vol. 40, no. 3, pp. 22–40, Fall 2016, doi: 10.1162/COMJ_a_00373.  
[17] L. Turchet, "Smart musical instruments for extended reality," *IEEE Access*, vol. 9, pp. 41 847–41 859, 2021, doi: 10.1109/ACCESS.2021.3065157.  
[18] M. Poletti, "Spatial audio for virtual reality," in *Proc. Audio Engineering Society Conference: 2016 AES International Conference on Audio for Virtual and Augmented Reality (AVAR)*, Los Angeles, CA, USA, Sept. 2016, Paper 4. [Online]. Available: https://www.aes.org/e-lib/browse.cfm?elib=18446  
[19] C. Armstrong, "Audio latency and synchronization in mobile XR," in *Proc. Audio Engineering Society Conference: 2020 AES International Conference on Audio for Virtual and Augmented Reality*, Aug. 2020. [Online]. Available: https://www.aes.org/e-lib/browse.cfm?elib=20875  
[20] H. Ziegelwanger, P. Majdak, and W. Kreuzer, "Numerical calculation of head-related transfer functions and sound localization in virtual reality," *Journal of the Audio Engineering Society*, vol. 63, no. 3, pp. 136–149, Mar. 2015, doi: 10.17743/jaes.2015.0003.  

---

## Reproducibility Statement
To uphold the highest standards of scientific reproducibility, all benchmarking scripts, raw measurement datasets (JSON and CSV formats), and the interactive HTML test harness have been archived and prepared for open release upon publication. Review copies of the raw datasets and code are included in the supplementary materials accompanying this manuscript submission.
